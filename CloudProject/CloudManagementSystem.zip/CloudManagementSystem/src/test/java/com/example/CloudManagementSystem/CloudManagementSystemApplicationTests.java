package com.example.CloudManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
