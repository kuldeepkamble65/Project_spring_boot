package com.example.CloudManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudManagementSystemApplication.class, args);
	}

}
